fis.config.merge({
    modules : {
        optimizer : {
            'app/**.js' : 'uglify-js'
        }
    }
});